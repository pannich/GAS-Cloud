# zip everything in this folder
zip -r targetzipgas.zip .

# unzip wo creating new directory
unzip targetzipgas.zip -d /Users/nichada/MyCode/MPCS/MPCS51083_Cloud/final-project-pannich/mpcs-cc
