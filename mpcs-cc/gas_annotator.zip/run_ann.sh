#!/usr/bin/bash

# Acticate virtual env
cd /home/ec2-user/mpcs-cc/
source bin/activate

# Run
python /home/ec2-user/mpcs-cc/annotator.py
